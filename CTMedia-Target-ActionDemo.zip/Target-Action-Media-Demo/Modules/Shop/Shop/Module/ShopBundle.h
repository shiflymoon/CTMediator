//
//  ShopBundle.h
//  Shop
//
//  Created by yangke on 2017/9/17.
//  Copyright © 2017年 jackie@youzan. All rights reserved.
//

#import "ModuleBundle.h"

@interface ShopBundle : ModuleBundle

@end
