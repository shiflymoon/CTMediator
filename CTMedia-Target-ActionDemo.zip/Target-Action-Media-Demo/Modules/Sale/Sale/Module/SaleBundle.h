//
//  YZSaleBundle.h
//  SaleModule
//
//  Created by youzan on 2017/2/28.
//  Copyright (c) 2017年 youzan. All rights reserved.
//

#import "ModuleBundle.h"

@interface SaleBundle : ModuleBundle

@end
