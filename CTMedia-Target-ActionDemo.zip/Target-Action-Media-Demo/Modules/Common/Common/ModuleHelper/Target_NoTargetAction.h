//
//  Target_NoTargetAction.h
//  Common
//
//  Created by 史贵岭 on 2019/8/5.
//  Copyright © 2019年 史贵岭. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface Target_NoTargetAction : NSObject
-(void) Action_response:(NSDictionary *) params;
@end

NS_ASSUME_NONNULL_END
