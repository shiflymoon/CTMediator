//
//  BaseService.h
//  Common
//
//  Created by yangke on 2017/9/16.
//  Copyright © 2017年 jackie@youzan. All rights reserved.
//

#import <Foundation/Foundation.h>


/**
 Base service class. All other services should be it's subclasses.
 */
@interface BaseService : NSObject

@end
