//
//  GoodsModel.m
//  Good
//
//  Created by 史贵岭 on 2019/8/7.
//  Copyright © 2019年 史贵岭. All rights reserved.
//

#import "GoodsModel.h"

@implementation GoodsModel

@end
