//
//  HomeBundle.h
//  Home
//
//  Created by yangke on 2017/9/16.
//  Copyright © 2017年 jackie@youzan. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ModuleBundle.h"

@interface HomeBundle : ModuleBundle

@end
