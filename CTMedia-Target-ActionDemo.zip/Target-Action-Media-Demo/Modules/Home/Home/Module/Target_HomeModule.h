//
//  HomeModuleTarget.h
//  Home
//
//  Created by 史贵岭 on 2019/8/5.
//  Copyright © 2019年 史贵岭. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface Target_HomeModule : NSObject
-(double) Action_showHomeVC:(NSDictionary *) params;
@end

NS_ASSUME_NONNULL_END
